import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useMemo, useState } from "react";
import { FlatList, Image, KeyboardAvoidingView, Linking, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { getApiBaseUrl } from "@/constants/oauth";
import { buildAssistantReply, createMessageId } from "@/lib/nexus";
import { ALLOWED_ATTACHMENT_TYPES, AttachmentInput, MAX_ATTACHMENT_BYTES, MAX_ATTACHMENTS, validateAttachment, validateAttachmentCount } from "@/shared/chat";

type ChatAttachment = AttachmentInput & { id: string; url?: string };
type ChatMessage = { id: string; role: "assistant" | "user"; text: string; attachments: ChatAttachment[] };
const STORAGE_KEY = "nexus-ai-chat-v2";
const POLISH_PROMPTS = ["Ułóż mi szybki plan produktywnego dnia", "Wyjaśnij złożony temat prostymi słowami", "Pomóż mi coś dobrze napisać"];

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Nie udało się odczytać pliku."));
    reader.readAsDataURL(file);
  });
}

function formatSize(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Nie udało się odczytać nagrania."));
    reader.readAsDataURL(blob);
  });
}

export default function HomeScreen() {
  const colors = useColors();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [pending, setPending] = useState<ChatAttachment[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const sendMutation = trpc.chat.send.useMutation();
  const transcribeMutation = trpc.voice.transcribe.useMutation();
  const audioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(audioRecorder);
  const isRecording = recorderState.isRecording;
  const hasConversation = messages.length > 0;
  const greeting = useMemo(() => (hasConversation ? "Co chcesz teraz przeanalizować?" : "Jak mogę Ci dziś pomóc?"), [hasConversation]);

  useEffect(() => {
    void setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
  }, []);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (!raw) return;
      try { setMessages(JSON.parse(raw) as ChatMessage[]); } catch { setNotice("Nie udało się odtworzyć poprzedniej rozmowy."); }
    });
  }, []);

  useEffect(() => { void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(messages)); }, [messages]);

  const showNotice = (message: string) => { setNotice(message); setTimeout(() => setNotice(null), 4500); };

  const addFiles = async (files: File[]) => {
    if (Platform.OS !== "web") { showNotice("Wybór plików jest dostępny w wersji webowej aplikacji."); return; }
    const countError = validateAttachmentCount(pending.length + files.length);
    if (countError) { showNotice(countError); return; }
    const next: ChatAttachment[] = [];
    for (const file of files) {
      const error = validateAttachment({ name: file.name, mimeType: file.type, size: file.size });
      if (error) { showNotice(`${file.name}: ${error}`); continue; }
      try { next.push({ id: `${Date.now()}-${file.name}-${Math.random()}`, name: file.name, mimeType: file.type, size: file.size, dataUrl: await readFileAsDataUrl(file) }); }
      catch (error) { showNotice(error instanceof Error ? error.message : "Nie udało się dodać pliku."); }
    }
    setPending((current) => [...current, ...next]);
  };

  useEffect(() => {
    if (Platform.OS !== "web" || typeof document === "undefined") return;
    const paste = (event: ClipboardEvent) => { const files = Array.from(event.clipboardData?.files ?? []); if (files.length) { event.preventDefault(); void addFiles(files); } };
    document.addEventListener("paste", paste);
    return () => document.removeEventListener("paste", paste);
  });

  const chooseFiles = () => {
    if (Platform.OS !== "web" || typeof document === "undefined") { showNotice("Wybór plików jest dostępny w wersji webowej aplikacji."); return; }
    const inputElement = document.createElement("input");
    inputElement.type = "file";
    inputElement.multiple = true;
    inputElement.accept = ALLOWED_ATTACHMENT_TYPES.join(",");
    inputElement.onchange = () => void addFiles(Array.from(inputElement.files ?? []));
    inputElement.click();
  };

  const sendMessage = async (value = input) => {
    const trimmed = value.trim();
    if ((!trimmed && pending.length === 0) || sendMutation.isPending) return;
    try {
      const uploaded: ChatAttachment[] = [];
      for (const attachment of pending) {
        if (!attachment.dataUrl) continue;
        const response = await fetch(`${getApiBaseUrl()}/api/attachments/upload`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: attachment.name, mimeType: attachment.mimeType, size: attachment.size, dataUrl: attachment.dataUrl }) });
        const result = await response.json() as { url?: string; error?: string };
        if (!response.ok || !result.url) throw new Error(result.error || "Nie udało się przesłać załącznika.");
        uploaded.push({ ...attachment, dataUrl: undefined, url: result.url });
      }
      const userMessage: ChatMessage = { id: createMessageId(Date.now(), "user"), role: "user", text: trimmed, attachments: uploaded };
      setMessages((current) => [...current, userMessage]);
      setInput(""); setPending([]);
      const answer = await sendMutation.mutateAsync({ text: trimmed, attachments: uploaded.map(({ name, mimeType, size, url }) => ({ name, mimeType: mimeType as (typeof ALLOWED_ATTACHMENT_TYPES)[number], size, url: url ?? "" })) });
      setMessages((current) => [...current, { id: createMessageId(Date.now(), "assistant"), role: "assistant", text: answer.text || buildAssistantReply(), attachments: [] }]);
      if (Platform.OS !== "web") void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) { showNotice(error instanceof Error ? error.message : "Nie udało się wysłać wiadomości."); }
  };

  const toggleRecording = async () => {
    if (isRecording) {
      await audioRecorder.stop();
      const uri = audioRecorder.uri;
      if (!uri) { showNotice("Nie udało się zapisać nagrania."); return; }
      try {
        const response = await fetch(uri);
        const blob = await response.blob();
        const mimeType = blob.type || "audio/m4a";
        const dataUrl = await blobToDataUrl(blob);
        const uploadResponse = await fetch(`${getApiBaseUrl()}/api/audio/upload`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mimeType, size: blob.size, dataUrl }) });
        const uploadResult = await uploadResponse.json() as { url?: string; error?: string };
        if (!uploadResponse.ok || !uploadResult.url) throw new Error(uploadResult.error || "Nie udało się przesłać nagrania.");
        const transcription = await transcribeMutation.mutateAsync({ audioUrl: uploadResult.url, language: "pl" });
        setInput((current) => `${current}${current ? " " : ""}${transcription.text}`);
      } catch (error) { showNotice(error instanceof Error ? error.message : "Nie udało się rozpoznać nagrania."); }
      return;
    }
    try {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) { showNotice("Aby dyktować wiadomości, zezwól na dostęp do mikrofonu."); return; }
      await audioRecorder.prepareToRecordAsync();
      audioRecorder.record();
    }
    catch { showNotice("Nie udało się rozpocząć nagrywania. Sprawdź uprawnienia mikrofonu."); }
  };

  const dropHandlers = Platform.OS === "web" ? ({ onDragOver: (event: any) => event.preventDefault(), onDrop: (event: any) => { event.preventDefault(); void addFiles(Array.from(event.dataTransfer?.files ?? [])); } } as any) : {};

  return <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={styles.header}><View style={styles.brandRow}><View style={[styles.brandMark, { backgroundColor: colors.primary }]}><MaterialIcons name="auto-awesome" size={19} color="#ecfeff" /></View><View><Text style={[styles.brandName, { color: colors.foreground }]}>Nexus AI</Text><View style={styles.onlineRow}><View style={styles.statusDot} /><Text style={[styles.onlineText, { color: colors.muted }]}>Gotowy do pomocy</Text></View></View></View><Pressable onPress={() => setMessages([])} accessibilityLabel="Rozpocznij nową rozmowę" style={({ pressed }) => [styles.iconButton, { borderColor: colors.border, backgroundColor: colors.surface }, pressed && styles.pressed]}><Ionicons name="create-outline" size={20} color={colors.foreground} /></Pressable></View>
      {notice && <View style={[styles.notice, { backgroundColor: colors.error }]}><Ionicons name="alert-circle-outline" size={17} color="#fff" /><Text style={styles.noticeText}>{notice}</Text></View>}
      <FlatList data={messages} keyExtractor={(item) => item.id} contentContainerStyle={styles.listContent} showsVerticalScrollIndicator={false} ListHeaderComponent={<View {...dropHandlers}><View style={hasConversation ? styles.conversationHeader : styles.hero}>{!hasConversation && <><View style={[styles.orbOuter, { backgroundColor: colors.accent }]}><View style={[styles.orb, { backgroundColor: colors.primary }]}><MaterialIcons name="graphic-eq" size={36} color="#ecfeff" /></View></View><Text style={[styles.eyebrow, { color: colors.muted }]}>TWÓJ OSOBISTY ASYSTENT AI</Text><Text style={[styles.title, { color: colors.foreground }]}>Łatwiejszy sposób na myślenie.</Text><Text style={[styles.subtitle, { color: colors.muted }]}>Zapytaj o wszystko, przeanalizuj pomysł lub dołącz plik.</Text></>}{hasConversation && <Text style={[styles.conversationTitle, { color: colors.foreground }]}>{greeting}</Text>}</View>{!hasConversation && <View style={styles.promptList}>{POLISH_PROMPTS.map((prompt, index) => <Pressable key={prompt} onPress={() => sendMessage(prompt)} style={({ pressed }) => [styles.prompt, { borderColor: colors.border, backgroundColor: colors.surface }, pressed && styles.pressed]}><Text style={[styles.promptText, { color: colors.foreground }]}>{prompt}</Text><Ionicons name="arrow-forward" size={16} color={colors.primary} /></Pressable>)}</View>}</View>} renderItem={({ item }) => <View style={[styles.message, item.role === "user" ? styles.userMessage : styles.assistantMessage, { backgroundColor: item.role === "user" ? colors.primary : colors.surface, borderColor: colors.border }]}><Text style={[styles.messageText, { color: item.role === "user" ? "#ecfeff" : colors.foreground }]}>{item.text}</Text>{item.attachments.length > 0 && <View style={styles.messageAttachments}>{item.attachments.map((attachment) => attachment.mimeType.startsWith("image/") && attachment.dataUrl ? <Image key={attachment.id} source={{ uri: attachment.dataUrl }} style={styles.thumbnail} /> : <Pressable key={attachment.id} onPress={() => attachment.url && void Linking.openURL(attachment.url)} style={styles.fileLink}><Ionicons name="document-attach-outline" size={16} color={item.role === "user" ? "#ecfeff" : colors.primary} /><Text style={[styles.fileLinkText, { color: item.role === "user" ? "#ecfeff" : colors.primary }]}>{attachment.name}</Text></Pressable>)}</View>}</View>} ListFooterComponent={<View style={styles.footerSpace} />} />
      {(isRecording || transcribeMutation.isPending) && <View style={[styles.voiceStrip, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.voicePulse, { backgroundColor: colors.primary }]}><Ionicons name={isRecording ? "pause" : "sparkles-outline"} size={15} color="#ecfeff" /></View><View style={styles.waveform}>{[16, 25, 12, 31, 20, 28, 14, 24, 18, 29, 11, 22].map((height, index) => <View key={`${height}-${index}`} style={[styles.waveBar, { height, backgroundColor: colors.primary, opacity: isRecording ? 0.9 : 0.45 }]} />)}</View><Text style={[styles.voiceLabel, { color: colors.foreground }]}>{isRecording ? "Nagrywanie…" : "Rozpoznawanie mowy…"}</Text></View>}
      <View style={[styles.composer, { borderColor: colors.border, backgroundColor: colors.surface }]} {...dropHandlers}>
        {pending.length > 0 && <View style={styles.pendingList}>{pending.map((attachment) => <View key={attachment.id} style={[styles.pendingChip, { backgroundColor: colors.accent }]}>{attachment.mimeType.startsWith("image/") && attachment.dataUrl ? <Image source={{ uri: attachment.dataUrl }} style={styles.pendingThumb} /> : <Ionicons name="document-outline" size={16} color={colors.primary} />}<View style={styles.pendingCopy}><Text numberOfLines={1} style={[styles.pendingName, { color: colors.foreground }]}>{attachment.name}</Text><Text style={[styles.pendingSize, { color: colors.muted }]}>{formatSize(attachment.size)}</Text></View><Pressable onPress={() => setPending((current) => current.filter((item) => item.id !== attachment.id))} accessibilityLabel={`Usuń załącznik ${attachment.name}`}><Ionicons name="close-circle" size={18} color={colors.muted} /></Pressable></View>)}</View>}
        <View style={styles.composerRow}><TextInput value={input} onChangeText={setInput} onSubmitEditing={() => void sendMessage()} placeholder="Napisz wiadomość…" placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground }]} returnKeyType="send" multiline maxLength={8000} /><Pressable onPress={chooseFiles} accessibilityLabel="Dodaj załącznik" style={({ pressed }) => [styles.roundButton, { backgroundColor: colors.accent }, pressed && styles.pressed]}><Ionicons name="attach-outline" size={19} color={colors.primary} /></Pressable><Pressable onPress={() => void toggleRecording()} accessibilityLabel={isRecording || transcribeMutation.isPending ? "Zatrzymaj nagrywanie" : "Nagraj wiadomość głosową"} style={({ pressed }) => [styles.roundButton, { backgroundColor: isRecording || transcribeMutation.isPending ? colors.primary : colors.accent }, pressed && styles.pressed]}><Ionicons name={isRecording ? "stop" : "mic-outline"} size={19} color={isRecording || transcribeMutation.isPending ? "#ecfeff" : colors.primary} /></Pressable><Pressable onPress={() => void sendMessage()} accessibilityLabel="Wyślij wiadomość" style={({ pressed }) => [styles.sendButton, { backgroundColor: colors.primary, opacity: input.trim() || pending.length ? 1 : 0.45 }, pressed && styles.pressed]}><Ionicons name={sendMutation.isPending ? "hourglass-outline" : "arrow-up"} size={19} color="#ecfeff" /></Pressable></View>
        <Text style={[styles.dropHint, { color: colors.muted }]}>Przeciągnij pliki tutaj lub wklej je przez Ctrl+V / Cmd+V · maks. {MAX_ATTACHMENTS} plików, 25 MB każdy</Text>
      </View>
    </KeyboardAvoidingView>
  </ScreenContainer>;
}

const styles = StyleSheet.create({ flex: { flex: 1 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 8, paddingBottom: 10 }, brandRow: { flexDirection: "row", alignItems: "center", gap: 11 }, brandMark: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, brandName: { fontSize: 16, fontWeight: "800" }, onlineRow: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 2 }, statusDot: { width: 7, height: 7, borderRadius: 7, backgroundColor: "#2dd4bf" }, onlineText: { fontSize: 11 }, iconButton: { width: 39, height: 39, borderWidth: 1, borderRadius: 13, alignItems: "center", justifyContent: "center" }, notice: { marginHorizontal: 20, marginBottom: 6, borderRadius: 12, padding: 10, flexDirection: "row", gap: 7, alignItems: "center" }, noticeText: { color: "#fff", flex: 1, fontSize: 12 }, listContent: { paddingHorizontal: 20, paddingBottom: 8 }, hero: { alignItems: "center", paddingTop: 22, paddingBottom: 24 }, orbOuter: { width: 156, height: 156, borderRadius: 80, alignItems: "center", justifyContent: "center", marginBottom: 27 }, orb: { width: 92, height: 92, borderRadius: 48, alignItems: "center", justifyContent: "center" }, eyebrow: { fontSize: 10, fontWeight: "700", letterSpacing: 1.7, marginBottom: 11 }, title: { fontSize: 29, fontWeight: "800", letterSpacing: -0.8, textAlign: "center" }, subtitle: { fontSize: 14, lineHeight: 21, textAlign: "center", marginTop: 10, maxWidth: 320 }, conversationHeader: { paddingTop: 20, paddingBottom: 12 }, conversationTitle: { fontSize: 23, fontWeight: "800" }, promptList: { gap: 9, marginTop: 18 }, prompt: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", minHeight: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14 }, promptText: { fontSize: 13, fontWeight: "600" }, message: { maxWidth: "88%", borderWidth: 1, borderRadius: 18, paddingHorizontal: 15, paddingVertical: 12, marginBottom: 10 }, userMessage: { alignSelf: "flex-end", borderBottomRightRadius: 5 }, assistantMessage: { alignSelf: "flex-start", borderBottomLeftRadius: 5 }, messageText: { fontSize: 14, lineHeight: 20 }, messageAttachments: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 9 }, thumbnail: { width: 70, height: 70, borderRadius: 10 }, fileLink: { flexDirection: "row", alignItems: "center", gap: 5, maxWidth: 200 }, fileLinkText: { fontSize: 12, textDecorationLine: "underline" }, footerSpace: { height: 8 }, voiceStrip: { marginHorizontal: 16, marginBottom: 7, borderWidth: 1, borderRadius: 18, padding: 10, flexDirection: "row", alignItems: "center", gap: 9 }, voicePulse: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" }, waveform: { flexDirection: "row", alignItems: "center", gap: 3, flex: 1 }, waveBar: { width: 3, borderRadius: 3 }, voiceLabel: { fontSize: 11, fontWeight: "700" }, composer: { marginHorizontal: 16, marginBottom: 10, borderWidth: 1, borderRadius: 21, padding: 7, paddingLeft: 10 }, composerRow: { flexDirection: "row", alignItems: "flex-end", gap: 7 }, input: { flex: 1, minHeight: 36, maxHeight: 90, paddingTop: 8, paddingBottom: 7, paddingLeft: 5, fontSize: 14 }, roundButton: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" }, sendButton: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" }, pendingList: { flexDirection: "row", flexWrap: "wrap", gap: 7, paddingBottom: 7 }, pendingChip: { maxWidth: 180, minHeight: 44, borderRadius: 12, padding: 6, flexDirection: "row", alignItems: "center", gap: 6 }, pendingThumb: { width: 32, height: 32, borderRadius: 7 }, pendingCopy: { flex: 1 }, pendingName: { fontSize: 11, fontWeight: "700" }, pendingSize: { fontSize: 10, marginTop: 2 }, dropHint: { fontSize: 9, textAlign: "center", paddingTop: 6 }, pressed: { opacity: 0.72, transform: [{ scale: 0.97 }] } });
void styles;
